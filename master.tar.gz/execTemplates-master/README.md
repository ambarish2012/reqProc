# execTemplates

[![Run Status](https://api.shippable.com/projects/59c0de1db5bb22070042e614/badge?branch=master)](https://app.shippable.com/github/Shippable/execTemplates)

This repository will (eventually) contain all the scripts that are pieced together to execute a build on Shippable.

## Integrations

Under the integrations folder, you'll find the scripts that get executed when a particular integration gets used in a build.
